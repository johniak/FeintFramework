#!/bin/bash

mono manage.exe